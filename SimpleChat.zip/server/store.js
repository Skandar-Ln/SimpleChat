const store = {
    chat: {
        // ['chatId']: {
        //     key
        // },
    }
}

module.exports = store;
