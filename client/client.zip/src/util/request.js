import axios from 'axios';

return (...args) => {
    axios
}